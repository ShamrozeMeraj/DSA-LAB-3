// SHAMROZE MERAJ - L1S25BSCS0003

#include <iostream>
#include "CustomList.h"
using namespace std;

int main()
{
    int capacity;

    cout << "Enter maximum size of list: ";
    cin >> capacity;

    if (capacity <= 0)
    {
        cout << "Size must be greater than zero.\n";
        return 0;
    }

    CustomList<int> list(capacity);

    int choice;
    int value;
    int index;
    int rotations;

    do
    {
        cout << "\n===== GENERIC DATA STRUCTURES =====\n";
        cout << "1. Add element at start\n";
        cout << "2. Add element at end\n";
        cout << "3. Remove element from start\n";
        cout << "4. Remove element from end\n";
        cout << "5. Insert at index\n";
        cout << "6. Display list\n";
        cout << "7. Check if list is empty\n";
        cout << "8. Check if list is full\n";
        cout << "9. Show list size\n";
        cout << "10. Show last element\n";
        cout << "11. Search for an element\n";
        cout << "12. Sum of prime numbers\n";
        cout << "13. Second maximum even number\n";
        cout << "14. Second minimum odd number\n";
        cout << "15. Print duplicates\n";
        cout << "16. Rotate clockwise\n";
        cout << "17. Rotate anti-clockwise\n";
        cout << "0. Exit\n";

        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            cout << "Enter value: ";
            cin >> value;
            list.addElementAtFirstIndex(value);
            break;

        case 2:
            cout << "Enter value: ";
            cin >> value;
            list.addElementAtLastIndex(value);
            break;

        case 3:
            list.removeElementFromStart();
            break;

        case 4:
            value = list.removeElementFromEnd();
            cout << "Returned value: " << value << endl;
            break;

        case 5:
            cout << "Enter index: ";
            cin >> index;

            cout << "Enter value: ";
            cin >> value;

            if (list.insertAt(index, value))
                cout << "Element inserted successfully.\n";
            else
                cout << "Invalid index or list is full.\n";

            break;

        case 6:
            list.display();
            break;

        case 7:
            if (list.empty())
                cout << "List is empty.\n";
            else
                cout << "List is not empty.\n";
            break;

        case 8:
            if (list.full())
                cout << "List is full.\n";
            else
                cout << "List is not full.\n";
            break;

        case 9:
            cout << "Current size: " << list.size() << endl;
            break;

        case 10:
            if (!list.empty())
                cout << "Last element: " << list.last() << endl;
            else
                cout << "List is empty.\n";
            break;

        case 11:
            cout << "Enter value to search: ";
            cin >> value;

            if (list.search(value))
                cout << "Value found.\n";
            else
                cout << "Value not found.\n";

            break;

        case 12:
            cout << "Sum of prime numbers: "
                 << list.sum_ofPrime() << endl;
            break;

        case 13:
            cout << "Second maximum even number: "
                 << list.secondMaxEven() << endl;
            break;

        case 14:
            cout << "Second minimum odd number: "
                 << list.secondMinOdd() << endl;
            break;

        case 15:
            cout << "Duplicate elements: ";
            list.printDuplicates();
            break;

        case 16:
            cout << "Enter number of rotations: ";
            cin >> rotations;

            if (rotations >= 0)
            {
                list.rotateClockwaise(rotations);
                list.display();
            }
            else
                cout << "Enter a non-negative number.\n";

            break;

        case 17:
            cout << "Enter number of rotations: ";
            cin >> rotations;

            if (rotations >= 0)
            {
                list.rotateanitclockwaise(rotations);
                list.display();
            }
            else
                cout << "Enter a non-negative number.\n";

            break;

        case 0:
            cout << "Program ended.\n";
            break;

        default:
            cout << "Invalid choice. Try again.\n";
        }

    } while (choice != 0);

    return 0;
}
