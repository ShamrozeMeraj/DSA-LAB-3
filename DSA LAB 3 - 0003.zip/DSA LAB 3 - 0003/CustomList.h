// SHAMROZE MERAJ - L1S25BSCS0003

#ifndef CUSTOMLIST_H
#define CUSTOMLIST_H

#include <iostream>
#include "MyList.h"
using namespace std;

template <class Type>
class CustomList : public MyList<Type>
{
public:
    CustomList(int size = 10, int count = 0)
        : MyList<Type>(size, count)
    {
    }

    CustomList(const CustomList<Type> &other)
        : MyList<Type>(other)
    {
    }

    ~CustomList()
    {
    }

    Type sum_ofPrime()
    {
        Type sum = 0;

        for (int i = 0; i < this->currentSize; i++)
        {
            int number = (int)this->arr[i];

            if (number < 2)
                continue;

            bool prime = true;

            for (int j = 2; j * j <= number; j++)
            {
                if (number % j == 0)
                {
                    prime = false;
                    break;
                }
            }

            if (prime)
                sum = sum + this->arr[i];
        }

        return sum;
    }

    Type secondMaxEven()
    {
        bool foundFirst = false;
        bool foundSecond = false;

        Type largest = Type();
        Type secondLargest = Type();

        for (int i = 0; i < this->currentSize; i++)
        {
            Type value = this->arr[i];

            if ((int)value % 2 == 0)
            {
                if (!foundFirst || value > largest)
                {
                    if (foundFirst && value != largest)
                    {
                        secondLargest = largest;
                        foundSecond = true;
                    }

                    largest = value;
                    foundFirst = true;
                }
                else if (value < largest &&
                         (!foundSecond || value > secondLargest))
                {
                    secondLargest = value;
                    foundSecond = true;
                }
            }
        }

        if (!foundSecond)
        {
            cout << "No second distinct even number.\n";
        }

        return secondLargest;
    }

    Type secondMinOdd()
    {
        bool foundFirst = false;
        bool foundSecond = false;

        Type smallest = Type();
        Type secondSmallest = Type();

        for (int i = 0; i < this->currentSize; i++)
        {
            Type value = this->arr[i];

            if ((int)value % 2 != 0)
            {
                if (!foundFirst || value < smallest)
                {
                    if (foundFirst && value != smallest)
                    {
                        secondSmallest = smallest;
                        foundSecond = true;
                    }

                    smallest = value;
                    foundFirst = true;
                }
                else if (value > smallest &&
                         (!foundSecond || value < secondSmallest))
                {
                    secondSmallest = value;
                    foundSecond = true;
                }
            }
        }

        if (!foundSecond)
        {
            cout << "No second distinct odd number.\n";
        }

        return secondSmallest;
    }

    void printDuplicates()
    {
        bool found = false;

        for (int i = 0; i < this->currentSize; i++)
        {
            bool alreadyChecked = false;

            for (int k = 0; k < i; k++)
            {
                if (this->arr[k] == this->arr[i])
                {
                    alreadyChecked = true;
                    break;
                }
            }

            if (alreadyChecked)
                continue;

            int count = 0;

            for (int j = 0; j < this->currentSize; j++)
            {
                if (this->arr[j] == this->arr[i])
                {
                    count++;
                }
            }

            if (count > 1)
            {
                cout << this->arr[i] << " ";
                found = true;
            }
        }

        if (!found)
        {
            cout << "No duplicates found.";
        }

        cout << endl;
    }

    void rotateClockwaise(int r)
    {
        if (this->currentSize < 2 || r <= 0)
            return;

        int firstHalf = this->currentSize / 2;
        int secondHalf = this->currentSize - firstHalf;

        // Rotate the first half clockwise.
        if (firstHalf > 0)
        {
            int turns = r % firstHalf;

            for (int turn = 0; turn < turns; turn++)
            {
                Type lastValue = this->arr[firstHalf - 1];

                for (int i = firstHalf - 1; i > 0; i--)
                {
                    this->arr[i] = this->arr[i - 1];
                }

                this->arr[0] = lastValue;
            }
        }

        // Rotate the second half clockwise.
        if (secondHalf > 0)
        {
            int start = firstHalf;
            int turns = r % secondHalf;

            for (int turn = 0; turn < turns; turn++)
            {
                Type lastValue = this->arr[this->currentSize - 1];

                for (int i = this->currentSize - 1; i > start; i--)
                {
                    this->arr[i] = this->arr[i - 1];
                }

                this->arr[start] = lastValue;
            }
        }
    }

    void rotateanitclockwaise(int rt)
    {
        if (this->currentSize < 2 || rt <= 0)
            return;

        int firstHalf = this->currentSize / 2;
        int secondHalf = this->currentSize - firstHalf;

        // Rotate the first half anti-clockwise.
        if (firstHalf > 0)
        {
            int turns = rt % firstHalf;

            for (int turn = 0; turn < turns; turn++)
            {
                Type firstValue = this->arr[0];

                for (int i = 0; i < firstHalf - 1; i++)
                {
                    this->arr[i] = this->arr[i + 1];
                }

                this->arr[firstHalf - 1] = firstValue;
            }
        }

        // Rotate the second half anti-clockwise.
        if (secondHalf > 0)
        {
            int start = firstHalf;
            int turns = rt % secondHalf;

            for (int turn = 0; turn < turns; turn++)
            {
                Type firstValue = this->arr[start];

                for (int i = start; i < this->currentSize - 1; i++)
                {
                    this->arr[i] = this->arr[i + 1];
                }

                this->arr[this->currentSize - 1] = firstValue;
            }
        }
    }
};

#endif
